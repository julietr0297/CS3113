/*
Emily Sillars
ems758
CS-UY 3113
Intro to Game Programming
HW #1
9/22/19
*/

#define GL_SILENCE_DEPRECATION

#ifdef _WINDOWS
#include <GL/glew.h>
#endif

#include <SDL.h>
#include <SDL_opengl.h>
#include <SDL_image.h>
#include "glm/mat4x4.hpp"
#include "glm/gtc/matrix_transform.hpp"
#include "ShaderProgram.h"

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

SDL_Window* displayWindow;
bool gameIsRunning = true;

ShaderProgram program;
ShaderProgram programTextures;
glm::mat4 viewMatrix, modelMatrix, projectionMatrix, viewMatrix2, projectionMatrix2;

float player_x = 0.0f;
float lastTicks = 0.0f;
float rotate_z = 0.0f;

GLuint player_textureID;

struct Food {
	float x;
	float y;
	float rotate_z;
	float speed;
	float rotate_speed;
	GLuint textureID;
	glm::mat4 modelMatrix;
};

struct Shape {
	float x;
	float y;
	float rotate_z;
	float speed;
	float rotate_speed;
	float vertices[6] = { 0.25f, -0.25f, 0.0f, 0.25f, -0.25f, -0.25f };
	glm::mat4 modelMatrix;
};

Food foods[5];
Shape shapes[5];

GLuint LoadTexture(const char* filePath) {
	int w, h, n;
	unsigned char* image = stbi_load(filePath, &w, &h, &n, STBI_rgb_alpha);

	if (image == NULL) {
		std::cout << "Unable to load image. Make sure the path is correct\n";
		assert(false);
	}

	GLuint textureID;
	glGenTextures(1, &textureID);
	glBindTexture(GL_TEXTURE_2D, textureID);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST); //could change to linear
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST); //behavior of scaling

	stbi_image_free(image);
	return textureID;
}

void Initialize() {
	SDL_Init(SDL_INIT_VIDEO);
	displayWindow = SDL_CreateWindow("Homework #1", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, 640, 480, SDL_WINDOW_OPENGL);
	SDL_GLContext context = SDL_GL_CreateContext(displayWindow);
	SDL_GL_MakeCurrent(displayWindow, context);

#ifdef _WINDOWS
	glewInit();
#endif

	glViewport(0, 0, 640, 480);

	programTextures.Load("shaders/vertex_textured.glsl", "shaders/fragment_textured.glsl");
	program.Load("shaders/vertex.glsl", "shaders/fragment.glsl");
	
	viewMatrix = glm::mat4(1.0f);
	modelMatrix = glm::mat4(1.0f);
	projectionMatrix = glm::ortho(-5.0f, 5.0f, -3.75f, 3.75f, -1.0f, 1.0f);

	viewMatrix2 = glm::mat4(1.0f);
	projectionMatrix2 = glm::ortho(-5.0f, 5.0f, -3.75f, 3.75f, -1.0f, 1.0f);

	program.SetProjectionMatrix(projectionMatrix2);
	program.SetViewMatrix(viewMatrix2);
	program.SetColor((227.0f/255.0f), (116.0f/255.0f), (168.0f/255.0f), 1.0f); //pink

	programTextures.SetProjectionMatrix(projectionMatrix);
	programTextures.SetViewMatrix(viewMatrix);



	glUseProgram(programTextures.programID);


	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	glClearColor(0.2f, 0.2f, 0.2f, 1.0f); //dark gray

	for (int i = 0; i < 5; i++) {
		shapes[i].modelMatrix = glm::mat4(1.0f);
		shapes[i].x = (-6.5f + (-i*1.5f));
		shapes[i].y = (-1.5f + (-i*1.5f));
		shapes[i].rotate_speed = (160.0f + (10 * i));
		shapes[i].rotate_z = 0.0f;
		shapes[i].speed = (1.0f + i * 1.0f);
		if (i % 2 == 0) {
			shapes[i].vertices[5] = -0.5f;
		}
		else {
			shapes[i].vertices[0] = 0.5f;

		}
	}

	for (int i = 0; i < 5; i++) {
		foods[i].textureID = LoadTexture("images/broccoli.png");
		if (i%2 != 0) {
			foods[i].textureID = LoadTexture("images/carrot.png");
		}
		foods[i].modelMatrix = glm::mat4(1.0f);
		foods[i].x = (-6.0f + (i*1.5f));
		foods[i].y = (-1.0f + (i*1.5f));
		foods[i].rotate_speed = (160.0f + (10 * i));
		foods[i].rotate_z = 0.0f;
		foods[i].speed = (1.0f + i * 1.0f);
	}
}

void ProcessInput() {
	SDL_Event event;
	while (SDL_PollEvent(&event)) {
		if (event.type == SDL_QUIT || event.type == SDL_WINDOWEVENT_CLOSE) {
			gameIsRunning = false;
		}
	}
}



void Update() {
	float ticks = (float)SDL_GetTicks() / 1000.0f;
	float deltaTime = ticks - lastTicks; //the fraction of a second that has passed.
	lastTicks = ticks;

	//move triangle
	player_x += 2.0f * deltaTime;
	//wrap if needed
	if (player_x > 5.0f) {
		player_x = -6.0;
	}
	modelMatrix = glm::mat4(1.0f);
	modelMatrix = glm::translate(modelMatrix, glm::vec3(player_x, -2.5f, 0.0f)); //make model matrix into translation matrix

	//move food
	for (int i = 0; i < 5; i++) {
		foods[i].rotate_z += foods[i].rotate_speed*deltaTime;
		//wrap if needed
		if (foods[i].x > 5.0f) {
			foods[i].x = -6.0 + -1 * i;
			foods[i].y = (-3.0f + (i*1.5f));
		}
		else {
			foods[i].x += foods[i].speed * deltaTime;
		}
		foods[i].modelMatrix = glm::mat4(1.0f);
		foods[i].modelMatrix = glm::translate(foods[i].modelMatrix, glm::vec3(foods[i].x, foods[i].y, 0.0f));

		foods[i].modelMatrix = glm::rotate(foods[i].modelMatrix,
			glm::radians(foods[i].rotate_z),
			glm::vec3(0.0f, 0.0f, 1.0f));
	}

	//move the shapes
	for (int i = 0; i < 5; i++) {
		shapes[i].rotate_z += shapes[i].rotate_speed*deltaTime;
		//wrap if needed
		if (shapes[i].x > 5.0f) {
			shapes[i].x = -6.0 + -1 * i;
			shapes[i].y = (-3.0f + (i*1.5f));
		}
		else {
			shapes[i].x += shapes[i].speed * deltaTime;
		}
		shapes[i].modelMatrix = glm::mat4(1.0f);
		shapes[i].modelMatrix = glm::translate(shapes[i].modelMatrix, glm::vec3(shapes[i].x, shapes[i].y, 0.0f));

		shapes[i].modelMatrix = glm::rotate(shapes[i].modelMatrix,
			glm::radians(shapes[i].rotate_z),
			glm::vec3(0.0f, 0.0f, 1.0f));
	}
}

void drawShapes(Shape aShape) {
	glUseProgram(0);
	glUseProgram(program.programID);
	program.SetModelMatrix(aShape.modelMatrix);
	glVertexAttribPointer(program.positionAttribute, 2, GL_FLOAT, false, 0, aShape.vertices);
	glEnableVertexAttribArray(program.positionAttribute);
	glDrawArrays(GL_TRIANGLES, 0, 3);
	glDisableVertexAttribArray(program.positionAttribute);
}

void drawFood(Food aFood) {
	glUseProgram(0);
	glUseProgram(programTextures.programID);
	programTextures.SetModelMatrix(aFood.modelMatrix);
	float vertices[] = { -0.5, -0.5, 0.5, -0.5, 0.5, 0.5, -0.5, -0.5, 0.5, 0.5, -0.5, 0.5 };
	float texCoords[] = { 0.0, 1.0, 1.0, 1.0, 1.0, 0.0, 0.0, 1.0, 1.0, 0.0, 0.0, 0.0 };

	glBindTexture(GL_TEXTURE_2D, aFood.textureID);

	glVertexAttribPointer(programTextures.positionAttribute, 2, GL_FLOAT, false, 0, vertices);
	glEnableVertexAttribArray(programTextures.positionAttribute);

	glVertexAttribPointer(programTextures.texCoordAttribute, 2, GL_FLOAT, false, 0, texCoords);
	glEnableVertexAttribArray(programTextures.texCoordAttribute);

	glDrawArrays(GL_TRIANGLES, 0, 6);

	glDisableVertexAttribArray(programTextures.positionAttribute);
	glDisableVertexAttribArray(programTextures.texCoordAttribute);
}

void drawTriangle() {
	glUseProgram(0);
	glUseProgram(program.programID);
	program.SetModelMatrix(modelMatrix);
	float vertices[] = { 0.5f, -0.5f, 0.0f, 0.5f, -0.5f, -0.5f };
	glVertexAttribPointer(program.positionAttribute, 2, GL_FLOAT, false, 0, vertices);
	glEnableVertexAttribArray(program.positionAttribute);
	glDrawArrays(GL_TRIANGLES, 0, 3);
	glDisableVertexAttribArray(program.positionAttribute);
}

void Render() {
	glClear(GL_COLOR_BUFFER_BIT);
	//draw triangle
	drawTriangle();
	//draw more triangles
	for (int i = 0; i < 5; i++) {
		drawShapes(shapes[i]);
	}
	//draw foods
	for (int i = 0; i < 5; i++) {
		drawFood(foods[i]);
	}
	SDL_GL_SwapWindow(displayWindow);
}

void Shutdown() {
	SDL_Quit();
}

int main(int argc, char* argv[]) {
	Initialize();

	while (gameIsRunning) {
		ProcessInput();
		Update();
		Render();
	}

	Shutdown();
	return 0;
}