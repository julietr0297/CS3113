#define GL_SILENCE_DEPRECATION

#ifdef _WINDOWS
#include <GL/glew.h>
#endif

#include <SDL.h>
#include <SDL_opengl.h>
#include <SDL_image.h>
#include "glm/mat4x4.hpp"
#include "glm/gtc/matrix_transform.hpp"
#include "ShaderProgram.h"

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

SDL_Window* displayWindow;
bool gameIsRunning = true;


ShaderProgram untexturedProgram;
ShaderProgram program;
glm::mat4 viewMatrix, modelMatrix, untexturedModelMatrix, movingMatrix, projectionMatrix;

GLuint playerTextureID;
GLuint shipTextureID;
GLuint manTextureID;

GLuint LoadTexture(const char* filePath) {
	int w, h, n;
	unsigned char* image = stbi_load(filePath, &w, &h, &n, STBI_rgb_alpha);

	if (image == NULL) {
		std::cout << "Unable to load image. Make sure the path is correct\n";
		assert(false);
	}

	GLuint textureID;
	glGenTextures(1, &textureID);
	glBindTexture(GL_TEXTURE_2D, textureID);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);

	stbi_image_free(image);
	return textureID;

}

void Initialize() {
	SDL_Init(SDL_INIT_VIDEO);
	displayWindow = SDL_CreateWindow("Textured", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, 640, 480, SDL_WINDOW_OPENGL);
	SDL_GLContext context = SDL_GL_CreateContext(displayWindow);
	SDL_GL_MakeCurrent(displayWindow, context);

#ifdef _WINDOWS
	glewInit();
#endif

	glViewport(0, 0, 640, 480);	//screen size. If changed adjus ortho size

	untexturedProgram.Load("shaders/vertex.glsl", "shaders/fragment.glsl");

	viewMatrix = glm::mat4(1.0f);
	untexturedModelMatrix = glm::mat4(1.0f);
	projectionMatrix = glm::ortho(-5.0f, 5.0f, -3.75f, 3.75f, -1.0f, 1.0f);

	untexturedProgram.SetProjectionMatrix(projectionMatrix);
	untexturedProgram.SetViewMatrix(viewMatrix);
	untexturedProgram.SetColor(1.0f, 1.0f, 0.0f, 1.0f);


	program.Load("shaders/vertex_textured.glsl", "shaders/fragment_textured.glsl");

	playerTextureID = LoadTexture("Stewart.png");
	shipTextureID = LoadTexture("spaceship.png");
	manTextureID = LoadTexture("notStewart.png");

	viewMatrix = glm::mat4(1.0f);
	modelMatrix = glm::mat4(1.0f);
	movingMatrix = glm::mat4(1.0f);

	program.SetProjectionMatrix(projectionMatrix);
	program.SetViewMatrix(viewMatrix);
	program.SetColor(1.0f, 1.0f, 1.0f, 1.0f);

	glUseProgram(program.programID);

	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);


	glClearColor(0.1f, 0.2f, 0.3f, 1.0f);  
}

void ProcessInput() {    //will contain key presses as input
	SDL_Event event;
	while (SDL_PollEvent(&event)) {
		if (event.type == SDL_QUIT || event.type == SDL_WINDOWEVENT_CLOSE) {
			gameIsRunning = false;
		}
	}
}

float lastTicks = 0;
float rotate_z = 0;
float away = -2;

void Update() {
	float ticks = (float)SDL_GetTicks() / 1000.0f;
	float deltaTime = ticks - lastTicks;
	lastTicks = ticks;

	away -= 0.5f * deltaTime;

	rotate_z += 45.0 * deltaTime;

	modelMatrix = glm::mat4(1.0f);
	
	movingMatrix = glm::translate(movingMatrix, glm::vec3(away, 0.0f, 0.0f));

}

void Render() {
	glClear(GL_COLOR_BUFFER_BIT);

	//tractor beam
	untexturedProgram.SetModelMatrix(untexturedModelMatrix);

	float beamVertices[] = { -1.5f, -0.5f, -0.3f, 2.0f, 0.3f, 2.0f, -1.5f, -0.5f, 1.5f, -0.5f, 0.3f, 2.0f};
	glVertexAttribPointer(untexturedProgram.positionAttribute, 2, GL_FLOAT, false, 0, beamVertices);
	glEnableVertexAttribArray(untexturedProgram.positionAttribute);
	glDrawArrays(GL_TRIANGLES, 0, 6);
	glDisableVertexAttribArray(untexturedProgram.positionAttribute);


	// guy texture
	movingMatrix = glm::translate(modelMatrix, glm::vec3(away, 0.0f, 0.0f));
	program.SetModelMatrix(movingMatrix);

	float manVertices[] = { -0.7, -0.7, 0.7, -0.7, 0.7, 0.7, -0.7, -0.7, 0.7, 0.7, -0.7, 0.7 };
	float manTexCoords[] = { 0.0, 1.0, 1.0, 1.0, 1.0, 0.0, 0.0, 1.0, 1.0, 0.0, 0.0, 0.0 };

	glBindTexture(GL_TEXTURE_2D, manTextureID);

	glVertexAttribPointer(program.positionAttribute, 2, GL_FLOAT, false, 0, manVertices);
	glEnableVertexAttribArray(program.positionAttribute);

	glVertexAttribPointer(program.texCoordAttribute, 2, GL_FLOAT, false, 0, manTexCoords);
	glEnableVertexAttribArray(program.texCoordAttribute);

	glDrawArrays(GL_TRIANGLES, 0, 6);

	glDisableVertexAttribArray(program.positionAttribute);
	glDisableVertexAttribArray(program.texCoordAttribute);


	// ship texture
	modelMatrix = glm::translate(modelMatrix, glm::vec3(0.0f, 2.0f, 0.0f));

	program.SetModelMatrix(modelMatrix);

	float shipVertices[] = { -2.0, -1.5, 2.0, -1.5, 2.0, 1.5, -2.0, -1.5, 2.0, 1.5, -2.0, 1.5 };
	float shipTexCoords[] = { 0.0, 1.0, 1.0, 1.0, 1.0, 0.0, 0.0, 1.0, 1.0, 0.0, 0.0, 0.0 };

	glBindTexture(GL_TEXTURE_2D, shipTextureID);

	glVertexAttribPointer(program.positionAttribute, 2, GL_FLOAT, false, 0, shipVertices);
	glEnableVertexAttribArray(program.positionAttribute);

	glVertexAttribPointer(program.texCoordAttribute, 2, GL_FLOAT, false, 0, shipTexCoords);
	glEnableVertexAttribArray(program.texCoordAttribute);

	glDrawArrays(GL_TRIANGLES, 0, 6);	

	glDisableVertexAttribArray(program.positionAttribute);
	glDisableVertexAttribArray(program.texCoordAttribute);


	//alien texture
	modelMatrix = glm::translate(modelMatrix, glm::vec3(0.0f, -1.7f, 0.0f));
	modelMatrix = glm::rotate(modelMatrix,
		glm::radians(rotate_z),
		glm::vec3(0.0f, 0.0f, 0.5f));	
											
	program.SetModelMatrix(modelMatrix);

	float vertices[] = { -0.7, -0.7, 0.7, -0.7, 0.7, 0.7, -0.7, -0.7, 0.7, 0.7, -0.7, 0.7 };
	float texCoords[] = { 0.0, 1.0, 1.0, 1.0, 1.0, 0.0, 0.0, 1.0, 1.0, 0.0, 0.0, 0.0 };

	glBindTexture(GL_TEXTURE_2D, playerTextureID);

	glVertexAttribPointer(program.positionAttribute, 2, GL_FLOAT, false, 0, vertices);
	glEnableVertexAttribArray(program.positionAttribute);

	glVertexAttribPointer(program.texCoordAttribute, 2, GL_FLOAT, false, 0, texCoords);
	glEnableVertexAttribArray(program.texCoordAttribute);

	glDrawArrays(GL_TRIANGLES, 0, 6);	//draws all the stuff

	glDisableVertexAttribArray(program.positionAttribute);
	glDisableVertexAttribArray(program.texCoordAttribute);
			//cleans up arrays


	

	SDL_GL_SwapWindow(displayWindow);
	//reset every frame
}

void Shutdown() {
	SDL_Quit();
}

int main(int argc, char* argv[]) {
	Initialize();	//doesn't need to be called in game loop since it's all the setup

	while (gameIsRunning) {
		ProcessInput();		//gameIsRunning check
		Update();		//changes things
		Render();		//draws changes
	}


	Shutdown();
	return 0;
}